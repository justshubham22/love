import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
} from "react-router";
import UserListPage from "./pages/UserListPage";
import Login from "./pages/Login";

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/">
      <Route path="" element={<Login />} />
      <Route path="users" element={<UserListPage />} />
    </Route>
  )
);

export default router;
