import loginImage from "../assets/loginImage.jpg";
import LoginForm from "../components/forms/LoginForm";

const Login = () => {
  return (
    <>
      <div
        className="login-form-container relative text-white    h-screen flex justify-center items-center duration-700 "
        style={{
          background:
            "linear-gradient(10deg, rgba(37,26,251,1) 0%, rgba(23,24,32,1) 58%)",

          backgroundPosition: "center",
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
        }}
      >
        {/* <LoginForm /> */}
        <div className="bg-black/40  rounded-xl flex border dark:border-gray-600 border-gray-400  gap-1 text-center w-3/4 md:w-3/4 lg:w-1/2 m-auto  dark:text-white text-black   flex-col sm:flex-row overflow-hidden mx-4">
          <div className="w-full  md:w-1/2  hidden  pe-0.5  sm:flex justify-center p-2 ">
            <img
              src={loginImage}
              alt="login Image"
              className="w-full h-full rounded-lg"
            />
          </div>

          <LoginForm />
        </div>
      </div>
    </>
  );
};

export default Login;
