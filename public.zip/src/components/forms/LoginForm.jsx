import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router";

const LoginForm = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const baseUrl = "https://reqres.in";
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const submitHandler = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const result = await axios.post(`${baseUrl}/api/login`, {
        email: email,
        password: password,
      });
      if (result.data.token) {
        setLoading(false);
        sessionStorage.setItem("token", result.data.token);
        navigate("/users");
      }
      console.log(result.data.token);
    } catch (error) {
      setLoading(false);
      console.log(error.response.data.error);
      alert(error.response.data.error);
    }
  };
  return (
    <div className="md:w-1/2 w-full flex flex-col  justify-center   border-gray-600 px-4 py-8">
      <div className="mb-6 ">
        {/* <img src={logo} alt="" className="w-3/4 m-auto block mb-4" /> */}

        <h2 className="text-blue-500 text-3xl font-bold">Login</h2>
        <p className="text-white mt-2">Enter email and password to login</p>
      </div>
      {/* ----- login form ------------  */}
      <form
        className="flex flex-col gap-3  text-black"
        onSubmit={(e) => submitHandler(e)}
      >
        <input
          type="text"
          placeholder="Enter Email"
          required
          onChange={(e) => setEmail(e.target.value)}
          className="px-2 py-2 rounded-md outline-none dark:text-white text-black dark:bg-black/20 border border-gray-600 focus:border-blue-500"
        />

        <input
          type="password"
          required
          placeholder="Enter Your Password"
          onChange={(e) => setPassword(e.target.value)}
          className="px-2 py-2 rounded-md outline-none  dark:bg-black/20 border  border-gray-600 text-white focus:border-blue-500"
        />
        <button
          type="submit"
          className="bg-blue-500  text-white p-2 rounded-md hover:bg-blue-700 transition duration-500 "
        >
          {loading ? "Authenticating ...." : "Login"}
        </button>
      </form>
    </div>
  );
};
export default LoginForm;
